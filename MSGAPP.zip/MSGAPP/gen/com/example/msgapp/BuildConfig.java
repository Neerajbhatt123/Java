/** Automatically generated file. DO NOT MODIFY */
package com.example.msgapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}