package com.example.lemon;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    Button btn,btn1,btn2,btn3;
    TextView tv;
    EditText et,et1,et2;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        btn=(Button)findViewById(R.id.button1);
        btn1=(Button)findViewById(R.id.button2);
        btn2=(Button)findViewById(R.id.button3);
        btn3=(Button)findViewById(R.id.button4);
        
        et=(EditText)findViewById(R.id.editText1);
        et1=(EditText)findViewById(R.id.editText2);
        et2=(EditText)findViewById(R.id.editText3);
        
        tv=(TextView)findViewById(R.id.textView1);
        
        btn.setOnClickListener(new a());
        btn1.setOnClickListener(new b());
        btn2.setOnClickListener(new c());
        btn3.setOnClickListener(new d());
    }
    class a implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
		String name=et.getText().toString();
		String name1=et1.getText().toString();
		int num1=Integer.parseInt(name);
		int num2=Integer.parseInt(name1);
		int result=num1+num2;
		String result1=String.valueOf(result);
		et2.setText(result1);
			
		}
    	
    }
    class b implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
		String name=et.getText().toString();
		String name1=et1.getText().toString();
		int num1=Integer.parseInt(name);
		int num2=Integer.parseInt(name1);
		int result=num1-num2;
		String result1=String.valueOf(result);
		et2.setText(result1);
			
		}
    	
    }
    class c implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
		String name=et.getText().toString();
		String name1=et1.getText().toString();
		int num1=Integer.parseInt(name);
		int num2=Integer.parseInt(name1);
		int result=num1*num2;
		String result1=String.valueOf(result);
		et2.setText(result1);
			
		}
    	
    }
    class d implements OnClickListener{

		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
		String name=et.getText().toString();
		String name1=et1.getText().toString();
		int num1=Integer.parseInt(name);
		int num2=Integer.parseInt(name1);
		int result=num1/num2;
		String result1=String.valueOf(result);
		et2.setText(result1);
			
		}
    	
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
