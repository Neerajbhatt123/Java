package com.example.df;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class MainActivity extends TabActivity {
	TabHost tabHost;
	TabSpec spec1,spec2,spec3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		tabHost=(TabHost)findViewById(android.R.id.tabhost);
		tabHost.setup();
		spec1=tabHost.newTabSpec("Tab 1");
		spec1.setContent(R.id.tab1);
		spec1.setIndicator("Chat",getResources().getDrawable(R.drawable.ic_launcher));
		Intent in1=new Intent(this,MainActivity1.class);
		spec1.setContent(in1);
		

		spec2=tabHost.newTabSpec("Tab 2");
		spec2.setContent(R.id.tab2);
		spec2.setIndicator("Chat",getResources().getDrawable(R.drawable.ic_launcher));
		Intent in2=new Intent(this,MainActivity2.class);
		spec1.setContent(in2);
		
		spec3=tabHost.newTabSpec("Tab 3");
		spec3.setContent(R.id.tab2);
		spec3.setIndicator("Chat",getResources().getDrawable(R.drawable.ic_launcher));
		Intent in3=new Intent(this,MainActivity2.class);
		spec1.setContent(in3);
		
		tabHost.addTab(spec1);
		tabHost.addTab(spec2);
		tabHost.addTab(spec3);
		

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
