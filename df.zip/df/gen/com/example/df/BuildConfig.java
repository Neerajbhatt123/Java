/** Automatically generated file. DO NOT MODIFY */
package com.example.df;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}